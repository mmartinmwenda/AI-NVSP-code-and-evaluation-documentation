from fastapi.testclient import TestClient
from ai_nvsp.api import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["mode"] == "demo"

def test_assessment_returns_tools_and_evidence():
    response = client.post("/assess", json={
        "farmer_id": "TEST-001",
        "county": "Kitui",
        "crop": "maize",
        "question": "Assess drought risk",
        "rainfall_status": "below_normal",
        "soil_status": "adequate",
        "market_need": True
    })
    assert response.status_code == 200
    data = response.json()
    assert "get_weather_data" in data["tools_used"]
    assert "assess_crop_risk" in data["tools_used"]
    assert data["risk_level"] == "moderate"
    assert data["human_review_required"] is False
    assert len(data["evidence"]) >= 3

def test_unknown_risk_routes_for_review():
    response = client.post("/assess", json={
        "farmer_id": "TEST-002",
        "county": "Turkana",
        "crop": "sorghum",
        "question": "What should I do?",
        "rainfall_status": "unknown",
        "soil_status": "unknown",
        "market_need": False
    })
    assert response.status_code == 200
    assert response.json()["human_review_required"] is True
    assert response.json()["status"] == "pending_human_review"

def test_audit_lookup():
    response = client.post("/assess", json={
        "farmer_id": "TEST-003",
        "county": "Nakuru",
        "crop": "potato",
        "question": "Check crop conditions",
        "rainfall_status": "normal",
        "soil_status": "adequate",
        "market_need": False
    })
    audit_id = response.json()["audit_id"]
    audit = client.get(f"/audit/{audit_id}")
    assert audit.status_code == 200
    assert audit.json()["audit_id"] == audit_id
