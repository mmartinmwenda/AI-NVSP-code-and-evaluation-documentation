from uuid import uuid4
from .domain import (
    get_weather_data, get_soil_crop_data, assess_crop_risk,
    get_input_market_information, search_agricultural_guidance,
    generate_farmer_advisory, flag_for_extension_review
)

AUDIT = {}

def assess(request):
    plan = [
        "Interpret the request and identify missing agricultural context",
        "Retrieve weather, soil/crop, and relevant guidance information",
        "Assess risk and decide whether human review is required",
        "Generate a recommendation and record the result"
    ]
    tools = []
    evidence = []

    # Use submitted context as the primary demo input. Adapters explicitly state
    # that they are demo-only and do not override user-supplied values.
    weather = get_weather_data(request.county)
    tools.append("get_weather_data")
    evidence.append({"source": weather["source"], "finding": weather["note"]})

    soil = get_soil_crop_data(request.county, request.crop)
    tools.append("get_soil_crop_data")
    evidence.append({"source": soil["source"], "finding": soil["note"]})

    guidance = search_agricultural_guidance(request.question)
    tools.append("search_agricultural_guidance")
    evidence.append({"source": guidance["source"], "finding": guidance["guidance"]})

    risk = assess_crop_risk(request.rainfall_status, request.soil_status, request.question)
    tools.append("assess_crop_risk")

    if request.market_need:
        market = get_input_market_information(request.county, request.crop)
        tools.append("get_input_market_information")
        evidence.append({"source": market["source"], "finding": market["note"]})

    advisory = generate_farmer_advisory(
        request.county, request.crop, risk["risk_level"],
        request.rainfall_status, request.soil_status
    )
    tools.append("generate_farmer_advisory")

    review_required = risk["human_review_required"]
    status = "recommendation_ready"
    if review_required:
        flag_for_extension_review(
            f"Risk level is {risk['risk_level']} or request needs specialist review",
            request.county, request.crop
        )
        tools.append("flag_for_extension_review")
        status = "pending_human_review"

    audit_id = str(uuid4())
    response = {
        "audit_id": audit_id,
        "plan": plan,
        "tools_used": tools,
        "risk_level": risk["risk_level"],
        "recommendation": advisory["recommendation"],
        "evidence": evidence,
        "human_review_required": review_required,
        "status": status
    }
    AUDIT[audit_id] = {
        "audit_id": audit_id,
        "farmer_id": request.farmer_id,
        "county": request.county,
        "crop": request.crop,
        "question": request.question,
        "result": response
    }
    return response
