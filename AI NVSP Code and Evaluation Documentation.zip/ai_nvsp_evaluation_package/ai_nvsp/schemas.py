from typing import Literal
from pydantic import BaseModel, Field

class AssessmentRequest(BaseModel):
    farmer_id: str = Field(default="DEMO", description="Use a pseudonymous ID in the demo.")
    county: str = Field(min_length=1, max_length=100)
    crop: str = Field(min_length=1, max_length=100)
    question: str = Field(min_length=3, max_length=2000)
    rainfall_status: Literal["normal", "below_normal", "unknown"] = "unknown"
    soil_status: Literal["adequate", "degraded", "unknown"] = "unknown"
    market_need: bool = False

class EvidenceItem(BaseModel):
    source: str
    finding: str

class AssessmentResponse(BaseModel):
    audit_id: str
    plan: list[str]
    tools_used: list[str]
    risk_level: Literal["low", "moderate", "high", "unknown"]
    recommendation: str
    evidence: list[EvidenceItem]
    human_review_required: bool
    status: Literal["recommendation_ready", "pending_human_review"]
