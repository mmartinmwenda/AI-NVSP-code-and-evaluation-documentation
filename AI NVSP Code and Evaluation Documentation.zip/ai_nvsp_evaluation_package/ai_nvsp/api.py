from fastapi import FastAPI, HTTPException
from .schemas import AssessmentRequest, AssessmentResponse
from .orchestrator import assess, AUDIT

app = FastAPI(
    title="AI-NVSP Agentic Agriculture Prototype",
    version="0.1.0",
    description="Evaluation prototype. Data adapters are demo-only; no live government APIs are connected."
)

@app.get("/health")
def health():
    return {"status": "ok", "mode": "demo"}

@app.post("/assess", response_model=AssessmentResponse)
def create_assessment(request: AssessmentRequest):
    return assess(request)

@app.get("/audit/{audit_id}")
def get_audit(audit_id: str):
    record = AUDIT.get(audit_id)
    if not record:
        raise HTTPException(status_code=404, detail="Audit record not found")
    return record
