"""MCP stdio server exposing the same demo domain functions to MCP clients."""
from mcp.server.fastmcp import FastMCP
from . import domain

mcp = FastMCP("ai-nvsp-agriculture-demo")

@mcp.tool()
def get_weather_data(county: str) -> dict:
    """Retrieve weather context. Demo adapter only, no live provider."""
    return domain.get_weather_data(county)

@mcp.tool()
def get_soil_crop_data(county: str, crop: str) -> dict:
    """Retrieve soil and crop context. Demo adapter only."""
    return domain.get_soil_crop_data(county, crop)

@mcp.tool()
def assess_crop_risk(rainfall_status: str, soil_status: str, question: str) -> dict:
    """Assess indicative risk from supplied context; not a validated forecast."""
    return domain.assess_crop_risk(rainfall_status, soil_status, question)

@mcp.tool()
def get_input_market_information(county: str, crop: str) -> dict:
    """Retrieve input/market context. Demo adapter only."""
    return domain.get_input_market_information(county, crop)

@mcp.tool()
def search_agricultural_guidance(query: str) -> dict:
    """Return demo agricultural guidance text."""
    return domain.search_agricultural_guidance(query)

@mcp.tool()
def generate_farmer_advisory(county: str, crop: str, risk_level: str,
                             rainfall_status: str, soil_status: str) -> dict:
    """Generate a rule-based example advisory for evaluation."""
    return domain.generate_farmer_advisory(
        county, crop, risk_level, rainfall_status, soil_status
    )

@mcp.tool()
def flag_for_extension_review(reason: str, county: str, crop: str) -> dict:
    """Flag a case for an authorised human reviewer; demo queue only."""
    return domain.flag_for_extension_review(reason, county, crop)

@mcp.resource("agriculture://guidance/core")
def core_guidance() -> str:
    """Core safety guidance for agricultural recommendations."""
    return domain.GUIDANCE

if __name__ == "__main__":
    mcp.run(transport="stdio")
