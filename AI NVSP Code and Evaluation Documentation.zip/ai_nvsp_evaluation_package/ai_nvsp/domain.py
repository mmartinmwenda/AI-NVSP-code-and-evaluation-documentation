"""Demo agricultural domain tools. Replace demo values with approved adapters."""
from datetime import datetime, timezone

GUIDANCE = (
    "Check local extension guidance before acting. Use verified local forecasts, "
    "soil test results, and crop-stage information. Escalate suspected pest or disease "
    "outbreaks and chemical-use questions to a qualified extension officer."
)

def get_weather_data(county: str) -> dict:
    return {
        "source": "demo_weather_adapter",
        "county": county,
        "rainfall_status": "unknown",
        "note": "Demo only. No live weather provider is connected."
    }

def get_soil_crop_data(county: str, crop: str) -> dict:
    return {
        "source": "demo_soil_crop_adapter",
        "county": county,
        "crop": crop,
        "soil_status": "unknown",
        "note": "Demo only. No live soil database is connected."
    }

def assess_crop_risk(rainfall_status: str, soil_status: str, question: str) -> dict:
    q = question.lower()
    if rainfall_status == "below_normal" and soil_status == "degraded":
        level = "high"
    elif rainfall_status == "below_normal" or soil_status == "degraded":
        level = "moderate"
    elif rainfall_status == "normal" and soil_status == "adequate":
        level = "low"
    else:
        level = "unknown"
    needs_review = any(term in q for term in (
        "pesticide", "chemical", "disease outbreak", "urgent", "poison"
    )) or level in ("high", "unknown")
    return {"risk_level": level, "human_review_required": needs_review}

def get_input_market_information(county: str, crop: str) -> dict:
    return {
        "source": "demo_market_adapter",
        "county": county,
        "crop": crop,
        "note": "Demo only. Verify input stock and prices with authorised local providers."
    }

def search_agricultural_guidance(query: str) -> dict:
    return {"source": "demo_guidance_resource", "guidance": GUIDANCE, "query": query}

def generate_farmer_advisory(county: str, crop: str, risk_level: str,
                             rainfall_status: str, soil_status: str) -> dict:
    if rainfall_status == "below_normal":
        advice = (
            f"For {crop} in {county}, check the latest local forecast and crop stage. "
            "Discuss moisture-conservation options, suitable planting decisions, and "
            "water management with your extension officer."
        )
    elif soil_status == "degraded":
        advice = (
            f"For {crop} in {county}, consider a locally appropriate soil test and "
            "discuss soil-fertility management with an extension officer."
        )
    else:
        advice = (
            f"For {crop} in {county}, confirm current local weather, crop stage, and "
            "soil conditions before selecting an intervention."
        )
    return {"recommendation": advice, "risk_level": risk_level}

def flag_for_extension_review(reason: str, county: str, crop: str) -> dict:
    return {
        "status": "pending_human_review",
        "assigned_role": "authorised_extension_officer",
        "county": county,
        "crop": crop,
        "reason": reason,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
