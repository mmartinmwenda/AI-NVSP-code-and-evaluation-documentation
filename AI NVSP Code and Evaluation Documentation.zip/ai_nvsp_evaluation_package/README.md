# AI-NVSP: Agentic Agricultural Decision Support
Version: 0.1.0 prototype

## Purpose
This repository is an evaluation-ready reference prototype for AI-NVSP, an agentic AI concept for Kenyan agriculture. It demonstrates a request-to-recommendation workflow, MCP tool exposure, structured outputs, human-review routing, and audit events.

**Implementation status:** This is a runnable reference prototype. Weather, soil, market, and KIAMIS integrations are represented by clearly labelled demo adapters. It does not connect to live Kenyan government systems or external data providers by default. Replace the demo adapters only after obtaining authorised API access and credentials.

## Architecture
1. A user submits an agricultural question to the FastAPI endpoint.
2. The orchestrator creates a plan and calls domain tools.
3. An MCP server exposes tools and resources through the Model Context Protocol.
4. The prototype's local orchestration calls the same domain functions directly for easy offline evaluation. The MCP server is runnable separately and exposes those functions to MCP-compatible clients.
5. The system generates a recommendation from returned evidence.
6. High-risk or uncertain cases are marked for extension-officer review.
7. An audit event records the request, tools used, result status, and review requirement.

The prototype uses deterministic rules instead of pretending an LLM has been configured. A model adapter is a future integration point. Configure a supported LLM only after selecting a provider, deployment method, and data-handling policy.

## Technology
- Python 3.11+
- FastAPI and Uvicorn for the HTTP API
- MCP Python SDK (`mcp`) for MCP server tools and resources
- Pydantic for request/response validation
- Pytest for tests

No external API key is required for the demo.

## Quick start
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn ai_nvsp.api:app --reload
```

Open `http://127.0.0.1:8000/docs` for interactive API documentation.

Example request:
```bash
curl -X POST http://127.0.0.1:8000/assess \
  -H "Content-Type: application/json" \
  -d '{"farmer_id":"DEMO-001","county":"Kitui","crop":"maize","question":"Assess drought risk and recommend next steps","rainfall_status":"below_normal","soil_status":"unknown","market_need":true}'
```

Expected response includes:
- a plan and tools invoked
- a risk assessment based on demo inputs
- an agricultural recommendation
- `human_review_required`
- an audit ID

## Run the MCP server
The MCP server uses stdio transport, suitable for local MCP clients:
```bash
python -m ai_nvsp.mcp_server
```
Add it to your MCP client configuration using the command for your Python environment and the absolute path to `ai_nvsp/mcp_server.py`, or run the module from the repository root. The exact configuration format depends on the MCP client.

The MCP server exposes tools:
- `get_weather_data`
- `get_soil_crop_data`
- `assess_crop_risk`
- `get_input_market_information`
- `search_agricultural_guidance`
- `generate_farmer_advisory`
- `flag_for_extension_review`

It also exposes the `agriculture://guidance/core` resource.

## API endpoints
- `GET /health`: health status
- `POST /assess`: run a demo assessment
- `GET /audit/{audit_id}`: retrieve an in-memory audit event

## Evaluation checklist
1. Start the API and open `/docs`.
2. Submit the example request above.
3. Confirm the response lists tools used and evidence sources.
4. Test `rainfall_status="below_normal"` and confirm the drought risk rises.
5. Test a question mentioning pesticide, disease outbreak, or urgent risk and confirm the system routes it for human review.
6. Start the MCP server with an MCP-compatible client and inspect its tools/resources.
7. Run `pytest -q`.

## Safety, limitations, and production work
- Demo outputs are illustrative, not agronomic advice.
- The prototype does not use a live LLM, live weather service, live market API, or live KIAMIS connection.
- The in-memory audit store is for demonstration only. Production requires durable storage, retention rules, role-based access control, monitoring, and secure secrets management.
- Do not submit identifiable farmer data to a model or third-party API without lawful authority, appropriate safeguards, and institutional approval.
- Human review is required for consequential recommendations, pest/disease incidents, chemical-use advice, financial decisions, and uncertain evidence.
- Before production: add authenticated users, data minimisation, encrypted transport/storage, API timeouts/retries, provider-specific adapters, source timestamps, evaluation datasets, bias and safety testing, observability, and deployment controls.
