# Evaluator Guide

## What this submission demonstrates
- A structured agent workflow with planning steps.
- Tool calls to separate agricultural functions.
- An MCP server exposing tools and a resource.
- Input validation and typed response schemas.
- Conditional human-review routing.
- Audit IDs and source notes.
- Automated tests for normal, drought, and unknown-context cases.

## Reproducible evaluation
```bash
pip install -r requirements.txt
pytest -q
uvicorn ai_nvsp.api:app --reload
```
Then open `http://127.0.0.1:8000/docs` and call `POST /assess`.

## Test cases
- Case A: rainfall `normal`, soil `adequate`, ordinary crop question. Expected risk: low, no review by default.
- Case B: rainfall `below_normal`, soil `adequate`. Expected risk: moderate, drought-related advisory, no review unless question indicates a specialist concern.
- Case C: rainfall and soil `unknown`. Expected risk: unknown and human review required.
- Case D: question mentions pesticide, chemical, disease outbreak, urgent, or poison. Expected human review.
- Case E: `market_need=true`. Expected `get_input_market_information` in the tool trace.

## Evidence and honesty
The prototype uses demo adapters and deterministic rules. It is suitable for reviewing the software structure and test workflow, not for claiming a deployed AI model or live integrations. Any application statement about implementation status should reflect the actual state of the team's working system.
