# Architecture and Evaluation Notes

## Components
- User interface: currently represented by FastAPI endpoints and Swagger UI.
- Orchestrator: deterministic multi-step workflow in `ai_nvsp/orchestrator.py`.
- Domain tools: reusable agricultural functions in `ai_nvsp/domain.py`.
- MCP server: `ai_nvsp/mcp_server.py`, exposing the functions as MCP tools and a guidance resource.
- Model layer: LLM is not connected in this prototype. The orchestration boundary is where a reviewed model adapter would be introduced.
- Data layer: demo adapters return explicit mock/demo responses. No persistent database is configured.
- Human oversight: uncertain/high-risk cases are flagged as pending review. The demo returns the review requirement; it does not send a real notification or assign a real officer.
- Audit: in-memory records for local evaluation.

## Flow
Request -> orchestrator plan -> MCP-equivalent domain tool calls -> evidence aggregation -> risk rules -> recommendation -> human-review flag if needed -> response + audit ID.

The HTTP orchestration invokes domain functions directly so the demo is simple to run. The MCP server separately exposes those same functions over MCP stdio. This is not a claim that the HTTP path currently invokes the MCP server as a remote client. To test full MCP client/server round-trips, connect an MCP-compatible host/client to `ai_nvsp/mcp_server.py` and invoke its tools.

## Evaluation dimensions
1. Tool selection and execution: verify the tool list changes when market information is requested.
2. Context sensitivity: compare normal rainfall with below-normal rainfall.
3. Safety: verify unknown or high-risk cases are flagged for review.
4. Traceability: verify each assessment returns an audit ID and source notes.
5. Interoperability: inspect tools and resource through an MCP-compatible client.
6. Reliability: run tests and inspect API validation behavior.

## Known limitations
- The risk logic is illustrative and not agronomically validated.
- Demo data are not authoritative and must not be used to guide real farming decisions.
- No live LLM, live weather/soil/market APIs, KIAMIS integration, authentication, persistent database, or actual reviewer queue is included.
- An actual production MCP client connection from the orchestrator is a next implementation step.
